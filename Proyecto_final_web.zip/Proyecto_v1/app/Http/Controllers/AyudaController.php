<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AyudaController extends Controller
{
    function show(){
        return view("Ayuda");
    }

    public function acercade(){
        return view('Acercade');
    }
}
