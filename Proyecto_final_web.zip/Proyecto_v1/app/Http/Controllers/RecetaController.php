<?php

namespace App\Http\Controllers;

use App\Models\Receta;
use Illuminate\Http\Request;

class RecetaController extends Controller
{
    function show(){
        $receta = Receta::where([
            ["paciente_id", '=',Auth()->user()->id],
        ])->get()->last();
        
        // bd($receta);
        if($receta){
            return view('ConsultarReceta',['receta' =>$receta]);
        }else {
            return redirect()->route('patient.menu');
        }
        
    }
}
