<?php

namespace App\Http\Controllers;

use App\Models\Cita;
use App\Models\Especialidad;
use App\Models\Medico;
use App\Models\padecimiento;
use Illuminate\Http\Request;
use Carbon\Carbon;


class AgendarCitaController extends Controller
{
    function show(){
        $especialidades = Especialidad::all();
        return view("Agendar", ["especialidades"=> $especialidades]);
    }

    function save(Request $request){
        $cita = new Cita();
        $fecha = Carbon::parse($request->fecha_concertada)->format('Y-m-d');
        $hora = Carbon::parse($request->hora_concertada)->format('H:i:s');

        $comprobarCita = Cita::where([
            ["medico_id", '=',$request->opMedico],
            ["fecha_concertada", '=', $fecha],
            ["hora_concertada", '=', $hora],
        ])->get();
        //dd($comprobarCita);
        //dd(count($comprobarCita));
        $citaCount = count($comprobarCita);
        
        //DB::table('planespago')->where('idCiclo', $idCiclo)->exists();

        if($citaCount === 0){
            //$cita->paciente_id = $request->id;
            //$fecha=Carbon::createFromFormat('d/m/Y', $request->fecha_concertada)->format('Y-m-d');
            $cita->paciente_id = auth()->user()->id;
            $cita->paciente_dni = " ";
            $cita->medico_id = $request->opMedico;
            $cita->fecha_concertada = $fecha;
            $cita->hora_concertada = $hora;
            $cita->examenes_previos = " ";

            $cita->save();
 
            return redirect()->route('patient.menu');
            //return redirect()->back()->with("success","");
        }
        else{
            $alert='No se puede ingresar';
            return redirect()->route('agendarCita')->with(['alert'=>$alert]);
            //return view('Agendar');
            // 
            // return $alert;
        }
      
    }
}