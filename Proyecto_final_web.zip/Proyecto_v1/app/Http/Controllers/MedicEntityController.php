<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\MedicoRequest;
use Illuminate\Support\Facades\Auth;
use App\Models\Especialidad;
use App\Models\entidad_medica;
use App\Models\User;

class MedicEntityController extends Controller
{
    // stodo esto esta hecho por anakin
    function show(){
        return view("entidad.MenuEntidadMedica");
    }

    public function login(MedicoRequest $request){
        $credentials = $request->getCredentials();

        if(Auth::validate($credentials)){
            return redirect()->route("users.login")->withErrors("auth.failed");

        }

        $user = Auth::getProvider()->retrieveByCredentials($credentials);

        Auth::login($user);

        return $this->authenticated($request,$user);
    }

    function entity_form(){
        $especialidades = Especialidad::all();
        return view("entidad.RegistroEntidadMedical", ["especialidades"=> $especialidades]);

    }
    ///esta aqui 

    public function create(Request $request)
    {
        // Validar los datos del formulario si es necesario
        $rol_entidad = 'e';
        // Crear la entidad
        $entidad = entidad_medica::create([
            'nombre_entidad' => $request->input('nombre_entidad'),
            'direccion' => $request->input('direccion'),
            'email' => $request->input('email'),
        ]);

        // Crear el usuario asociado a la entidad
        $user = User::create([
            'name' => $request->input('nombre_entidad'),
            'dni' => $request->input('rtn'),
            'email' => $request->input('email'),
            'password' => bcrypt($request->input('password')),
            'rol' => $rol_entidad,
        ]);

        // Asociar el usuario a la entidad
        $entidad->user()->save($user);

        // Redirigir a una ruta agregar.entidad
        return redirect()->route('agregar.entidad');
    }

    public function save(Request $request){
        $entidad = new entidad_medica();

        $entidad->nombre_entidad = $request->nombre_entidad;
        $entidad->direccion = $request->direccion;
        $entidad->email = $request->email;

        $datos = array(
            'name' => $request->nombre_entidad,
            'email' => $request->email,
            'dni' => $request->rtn,
            'password' => bcrypt($request->password)
        );

        $result = self::user($datos);

        if($result){
            $entidad->save();
            return redirect()->route('entidad.menu');
        }else{
            return redirect()->route('agregar.entidad');
        }
    }

    public function user($args){
        $user = new User();

        $user->name = $args['name'];
        $user->email = $args['email'];
        $user->password = $args['password'];
        $user->dni = $args['dni'];
        $user->rol = 'e';

        $result = $user->save();
        return $result;
    }
}
