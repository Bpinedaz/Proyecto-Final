<?php

namespace App\Http\Controllers;

use App\Models\Cita;
use App\Models\HistorialConsulta;
use App\Models\Medico;
use App\Models\Paciente;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HistorialController extends Controller
{
    public function showed(){
        return view('medico.consulta');
    }

    public function save(Request $request){
        $hist = new HistorialConsulta();
        $paciente = Paciente::where([
            ["dni", "=", $request->dni]
        ])->get()->pluck('id');

        $medico = Medico::where([
            ["email", "=", Auth()->user()->email]
        ])->get()->pluck('id');

        //dd($medico);
        $pat = intval($paciente[0]);
        $med =intval($medico[0]);

        $cita = Cita::where([
            ["paciente_id", "=",$pat]
        ])->get()->pluck('id')->last();
        //dd($cita);

        $hist->paciente_id = $pat;
        $hist->medico_id = $med;
        $hist->fecha = date("Y-m-d");
        $hist->sintoma_1 = $request->primersintoma;
        $hist->sintoma_2 = $request->segundosintoma;
        $hist->sintoma_3 = $request->tercersintoma;
        $hist->sintoma_4 = " ";
        $hist->comentarios_medico = $request->cometarios;
        $hist->examenes = $request->examenes;
        $hist->cita_id = $cita;
        $hist->receta_id = 0;
        $hist->peso = $request->peso;
        $hist->altura = $request->altura;
        $hist->presion_sanguinea = $request->presion;
        $hist->glucosa = $request->glucosa;
        $hist->alergia_1 = $request->alergia1;
        $hist->alergia_2 = $request->alergia2;
        $hist->fecha_actualizacion = date("Y-m-d");

        $result = $hist->save();
        if($result){
            return redirect()->route('show.medico');
        }else {
            return redirect()->route('historial.ingresar');
        }
    }
}
