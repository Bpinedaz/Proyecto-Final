<?php

namespace App\Http\Controllers;

use App\Http\Requests\MedicoRequest;
use App\Models\Especialidad;
use App\Models\Medico;
use App\Models\Paciente;
use App\Models\Receta;
use App\Models\User;
use Auth;
use Illuminate\Http\Request;

class MedicoController extends Controller
{
    
    public function show(){
        $especialidades = Especialidad::all();
        return view('entidad.RegistroMedico', ["especialidades"=> $especialidades]);
    }

    public function showed(){
        return view("medico.MenuMedico");
    }

    public function login(MedicoRequest $request){
        $credentials = $request->getCredentials();

        if(Auth::validate($credentials)){
            return redirect()->route("users.login")->withErrors("auth.failed");

        }

        $user = Auth::getProvider()->retrieveByCredentials($credentials);

        Auth::login($user);

        return $this->authenticated($request,$user);
    }

    public function authenticated(Request $request,$user){
        return redirect()->route("home");
    }

    public function list($id){
        $especialidad = Especialidad::find($id);
        $medico = Medico::where('especialidad',$especialidad->id)->get();
        return $medico;

    }

    public function save(Request $request){
        $medico = new Medico();
        $nombres = explode(" ",$request->txtname);
        $psswd = bcrypt($request->txtpsswd);

        $medico->dni = $request->txtdni;
        $medico->primer_nombre = str($nombres[0]);
        $medico->segundo_nombre = str($nombres[1]);
        $medico->primer_apellido = str($nombres[2]);
        $medico->segundo_apellido = str($nombres[3]);
        $medico->direccion = $request->txtdireccion;
        $medico->fecha_nacimiento = date("Y-m-d");;
        $medico->estad_civil = $request->estadocivil;
        $medico->sexo = $request->sexo;
        $medico->email = $request->txtemail;
        $medico->telefono = $request->txttelefono;
        $medico->usuario = " ";
        $medico->contraseña = $psswd;
        $medico->fecha_registro = date("Y-m-d");
        $medico->especialidad = $request->opEspecialidad;
        $medico->entidad_medica = Auth()->user()->id;

        $datos = array(
            'name'=> $request->txtname,
            'email'=> $request->txtemail,
            'dni'=> $request->txtdni,
            'password'=> $psswd
        );

        $result = self::user($datos);
        if($result){
            $medico->save();
            return redirect()->route('entidad.menu');
        }else{
            return redirect()->route('show.medico');
        }

    }

    public function user($args){
        $user = new User();

        $user->name = $args['name'];
        $user->email = $args['email'];
        $user->password = $args['password'];
        $user->dni = $args['dni'];
        $user->rol = 'm';

        $result = $user->save();
        return $result;
    }

    public function Mostrar_Recetas()
    {
        return view('medico.recetas');
    }

    private function generarNumeroRecetaUnico()
    {
        return rand(1, 9999);
    }

    public function Guardar_Receta(Request $request)
    {
        $paciente = Paciente::where([
            ["dni", "=", $request->paciente_id]
        ])->get()->pluck('id');

        $medico = Medico::where([
            ["email", "=", Auth()->user()->email]
        ])->get()->pluck('id');

        // Generar un número único para la receta
        $numeroReceta = $this->generarNumeroRecetaUnico();

        // Verificar si el número ya existe en la tabla 'receta'
        while (Receta::where('numero', $numeroReceta)->exists()) {
            // Si el número ya existe, genera uno nuevo
            $numeroReceta = $this->generarNumeroRecetaUnico();
            
        }

        $pat = intval($paciente[0]);
        $med =intval($medico[0]);

        $receta = new Receta();
        $receta->numero = $numeroReceta;
        $receta->secuencial = 1;
        $receta->medicamento = $request->medicamento;
        $receta->dosis = $request->dosis;
        $receta->periodicidad = $request->periodicidad ;
        $receta->medico_receta = $med;
        $receta->paciente_id = $pat;
        
        $result = $receta->save();
        
        if($result){
            return redirect()->route('medico.menu')->with('success', 'Receta guardada exitosamente');
        }else {
            return redirect()->route('ver.recetas');
        }
    }
}
