<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class entidad_medica extends Model
{
    protected $table = "entidad_medica";

    protected $fillable = ['nombre_entidad', 'direccion', 'email'];
}
