<?php

use App\Http\Controllers\AgendarCitaController;
use App\Http\Controllers\AyudaController;
use App\Http\Controllers\CitaController;
use App\Http\Controllers\HistorialController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\LogoutController;
use App\Http\Controllers\MedicEntityController;
use App\Http\Controllers\MedicoController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\SignupController;
use App\Http\Controllers\RecetaController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
////******trabajado aparte Sindy? */
Route::get('/obtener-receta/{id}', 'RecetaController@obtenerReceta')->name('recetas.obtener');


Route::view('/ConsultarReceta','ConsultarReceta');
Route::post('/obtener-recetas', [RecetaController::class, 'obtenerReceta'])->name('obtenerRecetas');
Route::get('/mostrarreceta',[RecetaController::class,'show'])->name('mostrarReceta');
//***********/

Route::get('/', [MainController::class, 'index'])->name('home');

Route::get('/login', [LoginController::class, 'showed'])->name('users.showed');//ya
Route::post('/login', [LoginController::class,'login'])->name('users.login');

Route::get('/signup', [SignupController::class, 'signup'])->name('users.signup');


Route::post('/signup', [PatientController::class,'store'])->name('users.store');//ya
Route::get('/menupatient', [PatientController::class,'patientMenu'])->name('patient.menu');//muestra la vista 

Route::get('/agendarcita', [AgendarCitaController::class,'show'])->name('agendarCita');//mostrar la vista

Route::post('/agendarcita', [AgendarCitaController::class,'save'])->name('guardarCita');//guardar la cita

Route::post('/storecita', [CitaController::class,'store'])->name('cita.store');//

Route::get('/logout',[LogoutController::class,'logout'])->name('users.logout');

Route::get('/medicos/{id}/medicosEspecialidad', [MedicoController::class,'list']);
Route::get('/medicomenu', [MedicoController::class,'showed'])->name('medico.menu');
///de aqui para arriba es lo que yo he hecho

//cosas de la entidad Anak
Route::get('/entidadmenu',[MedicEntityController::class,'show'])->name('entidad.menu');
Route::get('/addentidad',[MedicEntityController::class,'entity_form'])->name('agregar.entidad');
Route::post('/addentidad',[MedicEntityController::class,'save'])->name('guardar.entidad');
Route::get('/addmedicoentidad',[MedicoController::class,'show'])->name('show.medicoentidad');

//rutas para ingresar medicos por medio de la entidad medica
Route::get('/addmedico',[MedicoController::class,'showed'])->name('show.medico');
Route::post('/addmedico',[MedicoController::class,'save'])->name('guardar.medico');

//ruta para conocenos y ayudas
Route::get('/conocenos',[AyudaController::class,'acercade'])->name('conocer');
Route::get('/ayuda',[AyudaController::class,'show'])->name('ayuda');

//relacionado con el medico
Route::get('/menumedico',[MedicoController::class,'Mostrar_Medico_Menu']);
Route::get('/consulta',[MedicoController::class,'Mostrar_Consulta']);
Route::get('/medicomedview',[CitaController::class,'mostrarCitas'])->name('disponibilidad');
Route::get('/recetas',[MedicoController::class,'Mostrar_Recetas'])->name('ver.recetas');
Route::post('/recetas', [MedicoController::class, 'Guardar_Receta'])->name('recetas.guardar');

///Agregar consultas
Route::get('/historial',[HistorialController::class,'showed'])->name('historial.ingresar');
Route::post('/guardar',[HistorialController::class,'save'])->name('historial.guardar');