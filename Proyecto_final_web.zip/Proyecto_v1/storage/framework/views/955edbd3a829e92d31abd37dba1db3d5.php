
<!DOCTYPE html>
<html>
<head>
    <title>Agregar Receta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"] {
            width: calc(100% - 12px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <h1>Agregar Receta</h1>
    <form method="POST" action="<?php echo e(route('recetas.guardar')); ?>">
        <?php echo csrf_field(); ?>
        <label for="medicamento">Medicamento:</label>
        <input type="text" id="medicamento" name="medicamento"><br><br>

        <label for="dosis">Dosis:</label>
        <input type="text" id="dosis" name="dosis"><br><br>

        <label for="periodicidad">Periodicidad:</label>
        <input type="text" id="periodicidad" name="periodicidad"><br><br>

        <label for="paciente_id">DNI del Paciente:</label>
        <input type="text" id="paciente_id" name="paciente_id"><br><br>

        <input type="submit" value="Guardar Receta">
    </form>
</body>
</html>
<?php /**PATH C:\laragon\www\Proyecto_v1\resources\views/medico/recetas.blade.php ENDPATH**/ ?>