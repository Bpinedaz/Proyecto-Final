

<?php $__env->startSection('title','Menu Entidad'); ?>

<body>
    <div class="main-container">
        <div class="row">
          <div class="col s12">
            <h1>Menú Clinica</h1>
            <div class="row">
            <!-- ************ -->
              <div class="col s12 m12 columna">
                <div class="card Imgbk">
                  <div class="card-content">
                    <span class="card-title">Opción 1</span>
                    <p>Administración Medica</p>
                    <div class="file-field input-field col s12">
                      <a href="<?php echo e(route('agregar.entidad')); ?>" target="_self">
                        <div class="btn">
                        <i class="material-icons">widgets</i>
                          <span>Ir</span>
                          
                        </div>
                      </a>
                     
                      </div>

                  </div>
                </div>
              </div>


              <div class="col s12 m12 columna">
                <div class="card Imgbk">
                  <div class="card-content">
                    <span class="card-title">Opción 2</span>
                    <p>Administrar Medicos</p>
                    <div class="file-field input-field col s12">
                      <a href="<?php echo e(route('show.medico')); ?>" target="_self">
                        <div class="btn">
                        <i class="material-icons">widgets</i>
                          <span>Ir</span>
                          
                        </div>
                      </a>
                     
                      </div>

                  </div>
                </div>
              </div>

               <!-- ************ -->
               <div class="col s12 m12 columna"  >
                <div class="card">
                  <div class="card-content">
                    <span class="card-title">Opción 3</span>
                    <p>Pizarra de Pacientes</p>
                    <div class="file-field input-field col s12">
                      <a href="#" target="_self">
                        <div class="btn">
                        <i class="material-icons">widgets</i>
                          <span>Ir</span>
                          
                        </div>
                      </a>
                     
                      </div>

                  </div>
                </div>
              </div>

            </div>
              <!-- ****************** -->
           <div class="row">
            <div id="btn" class="col s12 m3">
                <a href="<?php echo e(route('home')); ?>" target="_self">
                    <button class="btn waves-effect waves-light" type="submit" name="action">
                     Salir
                      <i class="material-icons right">exit_to_app</i>
                     </button>
                </a>
                          
            </div>
           
          </div>
        </div>
      </div>
      
  
</body>
</html>
<?php echo $__env->make('entidad.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_v1\resources\views/entidad/MenuEntidadMedica.blade.php ENDPATH**/ ?>