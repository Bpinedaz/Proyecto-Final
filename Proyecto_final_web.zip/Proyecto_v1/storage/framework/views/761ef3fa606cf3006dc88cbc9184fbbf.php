<!DOCTYPE html>
<html>
<head>
    <title>Detalles de Consultas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <h1>Detalles de Consultas</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>ID del Paciente</th>
                <th>DNI del Paciente</th>
                <th>ID del Médico</th>
                <th>Fecha de la Cita</th>
                <th>Hora de la Cita</th>
                <th>Exámenes Previos</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cita->id); ?></td>
                <td><?php echo e($cita->paciente_id); ?></td>
                <td><?php echo e($cita->paciente_dni); ?></td>
                <td><?php echo e($cita->medico_id); ?></td>
                <td><?php echo e($cita->fecha_concertada); ?></td>
                <td><?php echo e($cita->hora_concertada); ?></td>
                <td><?php echo e($cita->examenes_previos); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\laragon\www\Proyecto_v1\resources\views/medico/disp_horario.blade.php ENDPATH**/ ?>