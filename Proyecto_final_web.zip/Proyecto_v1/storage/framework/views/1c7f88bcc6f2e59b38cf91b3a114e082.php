

<?php $__env->startSection('title','Menu Entidad'); ?>
<body>
   
    <div class="main-container">

        
    <form action="<?php echo e(route('guardar.medico')); ?>" method="POST">
        <?php echo csrf_field(); ?>
            <div class="row">
                <h1>Agregar Medico Especialista</h1>
            
                <div class="col s12 m12">
                <p>Nombre Completo del Medico</p>
                <input type="text" name="txtname" id="" placeholder="Nombre completo">
                </div>
                <div class="col s12 m6">
                <p>Numero de DNI</p>
                <input type="text" name="txtdni" id="" placeholder="DNI">
                </div>
                <div class="col s12 m6">
                <p>Numero Telefonico</p>
                <input type="text" name="txttelefono" id="" placeholder="Telefono">
                </div>
                <div class="col s12 m6">
                <p>Correo electronico</p>
                <input type="text" name="txtemail" id="" placeholder="Correo Electronico">
                </div>
                <div class="col s12 m6">
                <p>Contraseña</p>
                <input type="password" name="txtpsswd" id="" placeholder="Contraseña">
                <a class="waves-effect waves-light btn-small"><i class="material-icons">remove_red_eye</i></a>
                </div>
                <div class="col s12 m6">
                <p>Confirmar Contraseña</p>
                <input type="password" name="txtconf" id="" placeholder="Confirmar Contraseña">
                
                <a class="waves-effect waves-light btn-small"><i class="material-icons">remove_red_eye</i></a>
                </div>
                <div class="col s12 m6">
                <p>Numero de Consultorio</p>
                <input type="text" name="txtconsultorio" id="" placeholder="Numero de Consultorio">
                </div>
                <div class="col s12 m6">
                    <p>Direccion</p>
                    <input type="text" name="txtdireccion" id="" placeholder="Numero de Consultorio">
                </div>
                <div class="col s12 m6">
                    <p>Especialidad</p>
                    <select name="opEspecialidad" id="especialidad" class="browser-default">
                        <option value="" disabled selected>Selecciona la Especialidad</option>
                        <!-- Agrega aquí opciones de especialidades -->
                        <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($especialidad->id); ?>"><?php echo e($especialidad->descripcion); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- ... -->
                    </select>
                </div>
                <div>
                    <div>
                      <p>Estado Civil</p>
                    </div>
                    <p>
                      <label>
                        <input class="with-gap mb-2" name="estadocivil" type="radio" value="c"/>
                        <span>Casado</span>
                      </label>
                      <label>
                        <input class="with-gap mb-2" name="estadocivil" type="radio"  value="s"/>
                        <span>Soltero</span>
                      </label>
                      <label>
                        <input class="with-gap mb-2" name="estadocivil" type="radio"  value="v"/>
                        <span>Viudo</span>
                      </label>
                    </p>
                </div>

                <div>
                    <div>
                      <p>Sexo</p>
                    </div>
                    <p>
                      <label>
                        <input class="with-gap mb-2" name="sexo" type="radio" value="f"/>
                        <span>Femenino</span>
                      </label>
                      <label>
                        <input class="with-gap mb-2" name="sexo" type="radio"  value="m"/>
                        <span>Masculino</span>
                      </label>
                    </p>
                  </div>

                <br><br><br>
                <div id="btn" class="col s12 m6">
                    <button class="btn waves-effect waves-light" type="submit" name="action">Enviar Datos
                        <i class="material-icons right">send</i>
                    </button>  
                 </button>     
                </div>
    
                
                    
            </div>
           
        
    </form>
    </div>
    
    
    <div class="main-container">
      <a href="<?php echo e(route('entidad.menu')); ?>">
        <div id="btn" class="col s12 m6">
            <button class="btn waves-effect waves-light" type="submit" name="action">Cancelar
                  <i class="material-icons right">cancel</i>
              </button>            
        </div>
      </a>
    </div>    


</body>
</html>
<?php echo $__env->make('entidad.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Proyecto_v1/resources/views/entidad/RegistroMedico.blade.php ENDPATH**/ ?>