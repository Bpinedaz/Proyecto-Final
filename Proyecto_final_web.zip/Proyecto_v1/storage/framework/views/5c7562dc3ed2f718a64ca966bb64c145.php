

<?php $__env->startSection('title','Agendar Cita en Linea'); ?>

<?php $__env->startSection('content'); ?>

  <!-- Tu contenido HTML aquí -->
  <div class="main-container">
   
    <div class="container">
      <h1>Agendar Cita en Línea</h1>

      <form action="<?php echo e(route('guardarCita')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <!-- Selección de fecha y hora -->
        <div class="input-field">
          <input type="text" id="fecha" class="datepicker" name="fecha_concertada">
          <label for="fecha">Fecha</label>
        </div>
  
        <div class="input-field">
          <input type="text" id="hora" class="timepicker" name="hora_concertada">
          <label for="hora">Hora</label>
        </div>


        <div class="">
          <select name="opEspecialidad" id="especialidad" class="browser-default" onchange="loadmedicos(this)">
            <option value="" disabled selected>Selecciona la Especialidad</option>
            <!-- Agrega aquí opciones de especialidades -->
            <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($especialidad->id); ?>"><?php echo e($especialidad->descripcion); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- ... -->
          </select>
        </div>

        <div class="">
          <select name="opMedico" id="medico_list" class="browser-default">
            <option value="" disabled selected>Selecciona Medico</option>
            <!-- Agrega aquí opciones de especialidades -->
          </select>
        </div>

        <!-- Botones para consultar disponibilidad y agendar cita -->
        <button class="btn" type="button" onclick="consultarDisponibilidad()">Salir</button>
        <button class="btn" type="submit" name="action" onclick="agendarCita()">Agendar Cita</button>
      </form>
    </div>
  </div>
  
  <script>
    function loadmedicos(medicosSelect){
      let medicoId = medicosSelect.value;

      fetch('medicos/'+medicoId+'/medicosEspecialidad')
      .then(function(response){
        return response.json();
      })
      .then(function(jsonData){
        buildMedico(jsonData);
      })
    }

    function buildMedico(jsonMedico) {
      let medicoSelect = document.getElementById('medico_list')

      clearSelect(medicoSelect);

      jsonMedico.forEach(function(medico){
        let optionTag = document.createElement('option');
        optionTag.value = medico.id;
        optionTag.innerHTML = medico.primer_nombre +' '+medico.primer_apellido;

        medicoSelect.append(optionTag);
      });
    }

    function clearSelect(select){
      while (select.options.length>1){
        select.remove(1);
      }
    }
  </script>

 <!-- Fin de dibujo select -->


  <!-- Materialize JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

  <!-- Script para inicializar select, datepicker y timepicker -->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      var elems = document.querySelectorAll('.datepicker');
      var instances = M.Datepicker.init(elems);

      elems = document.querySelectorAll('.timepicker');
      instances = M.Timepicker.init(elems);
    });
  </script>


  <script>

    
    document.addEventListener('DOMContentLoaded', function() {
      var elems = document.querySelectorAll('.browser-default');
      var instances = M.FormSelect.init(elems);
    });

    function mostrarNombreMedico() {
      var especialidadSeleccionada = document.getElementById('especialidad').value;
      var nombreMedico = obtenerNombreMedico(especialidadSeleccionada);
      document.getElementById('nombreMedico').innerText = 'Nombre del Médico: ' + nombreMedico;
    }

    function obtenerNombreMedico(especialidad) {
      // Simulación de datos de médicos
      var medicos = {
        'Medicina General': 'Dr. Juan Pérez',
        'Cardiología': 'Dra. María Gómez'
        // Puedes agregar más especialidades y nombres de médicos según tus necesidades
      };

      return medicos[especialidad] || 'No disponible';
    }

    function consultarDisponibilidad() {
      // Obtener departamento y municipio seleccionados
      var departamento = document.getElementById('departamento').value;
      var municipio = document.getElementById('municipio').value;

      // Crear la URL de OpenStreetMap con la ubicación
      var url = 'https://www.google.com/maps/place/' + municipio + '%2C%20' + departamento;

      // Abrir la URL en una nueva pestaña
      window.open(url, '_blank');
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Proyecto_v1/resources/views/Agendar.blade.php ENDPATH**/ ?>