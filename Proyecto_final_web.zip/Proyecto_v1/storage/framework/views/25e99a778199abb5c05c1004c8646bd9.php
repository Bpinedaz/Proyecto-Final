<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <title>Consulta Recetas</title>
</head>
<body>
    <div class="main-container">
        <div class="row">
            <h1>Consulta de Recetas de la Ultima cita</h1>
            <div class="col s12 ">

            </div>

            <div class="col s12 m12">
                <form action="<?php echo e(route('obtenerRecetas')); ?>" method="POST">
                    <div>
                    </div>
                    <span>Se receto </span>
                    <label for="nombrePaciente">Nombre de Paciente</label>
                    <textarea id="miTextarea" name="miTextarea" rows="4" cols="50" value="" readonly><?php echo e(Auth()->user()->name); ?></textarea>
                    <br><br><br>
                    <label for="nombrePaciente">Medicamento</label>
                    <textarea id="miTextarea" name="miTextarea" rows="4" cols="100" value="" readonly><?php echo e($receta->medicamento); ?></textarea>
                    <br><br><br>
                    <label for="nombrePaciente">Indicaciones</label>
                    <textarea id="miTextarea" name="miTextarea" rows="4" cols="200" value="" readonly><?php echo e($receta->dosis); ?></textarea>
                    <br><br><br>
                    <label for="nombrePaciente">Periodicidad</label>
                    <textarea id="miTextarea" name="miTextarea" rows="4" cols="200" value="" readonly><?php echo e($receta->periodicidad); ?></textarea>
                   
                    <br><br><br>
                  </form>
            </div>


              <!-- ****************** -->
         <div class="row">
            <div id="btn" class="col s12 m3">
                <a href="<?php echo e(Route('patient.menu')); ?>" target="_self">
                    <button class="btn waves-effect waves-light" type="submit" name="action">
                     Regresar
                      <i class="material-icons right">arrow_back</i>
                     </button>
                </a>
                </div>         
          </div>
           <!-- ****************** -->

        <div class="row">
            <div id="btn" class="col s12 m3">
                <a href="/" target="_self">
                    <button class="btn waves-effect waves-light" type="submit" name="action">
                     Salir
                      <i class="material-icons right">exit_to_app</i>
                     </button>
                </a>
                          
          </div>

        </div>
       
        



    </div>



    
</body>
</html><?php /**PATH C:\laragon\www\Proyecto_v1\resources\views/ConsultarReceta.blade.php ENDPATH**/ ?>