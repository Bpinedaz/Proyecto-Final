

<?php $__env->startSection('title','Menu Entidad'); ?>
<body>
   
    <div class="main-container">

        
    <form action="<?php echo e(route('guardar.entidad')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <h1>Registro Entidad Medica</h1>
        
            <div class="col s12 m12">
            <p>Nombre de la entidad Medica</p>
            <input type="text" name="nombre_entidad" id="" placeholder="Entidad Medica">
            </div>
            <div class="col s12 m6">
            <p>Numero de RTN</p>
            <input type="text" name="rtn" id="" placeholder="RTN">
            </div>
            <div class="col s12 m6">
            <p>Correo electronico</p>
            <input type="text" name="email" id="" placeholder="Correo Electronico">
            </div>
            <div class="col s12 m6">
            <p>Contraseña</p>
            <input type="password" name="password" id="" placeholder="Contraseña">
            <a class="waves-effect waves-light btn-small"><i class="material-icons">remove_red_eye</i></a>
            </div>
            <div class="col s12 m6">
            <p>Confirmar Contraseña</p>
            <input type="password" name="passwordconf" id="" placeholder="Confirmar Contraseña">
            <a class="waves-effect waves-light btn-small"><i class="material-icons">remove_red_eye</i></a>
            </div>
            <div class="col s12 m12">
            <p>Direccion Exacta</p>
            <input type="text" name="direccion" id="" placeholder="Direccion Exacta">
            </div>
            <div class="col s12 m6">               
            </div>
                <br><br><br>
                <div id="btn" class="col s12 m6">
                    <button class="btn waves-effect waves-light" type="submit" name="action">Enviar Datos
                        <i class="material-icons right">send</i>
                    </button>  
                 </button>     
                </div>        
        </div>
           
        
    </form>
    </div>
    
    
    <div class="main-container">
            <div id="btn" class="col s12 m6">
                <button class="btn waves-effect waves-light" type="submit" name="action">Cancelar
                     <i class="material-icons right">cancel</i>
                  </button>            
            </div>
    </div>    


</body>
</html>
<?php echo $__env->make('entidad.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_v1\resources\views/entidad/RegistroEntidadMedical.blade.php ENDPATH**/ ?>