<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */

     public function up(): void
     {
         Schema::create('medicamento', function (Blueprint $table) {
             $table->id();
             $table->integer('lote');
             $table->string('marca');
             $table->string('dosis');
             $table->string('formula_farmaceutica');
             $table->string('embalaje',40);
             $table->integer('unidades_en_envase');
             $table->decimal('precio_empaque');
             $table->string('via_administracion');
             $table->date('fecha_vencimiento');
             $table->unsignedBigInteger('proveedor_id');
             $table->foreign('proveedor_id')->references('id')->on('proveedor')->onDelete('cascade');
             $table->timestamps();
         });
     }
 

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('medicamento');
    }
};
