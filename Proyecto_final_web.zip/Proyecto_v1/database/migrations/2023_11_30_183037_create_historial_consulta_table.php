<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
     public function up(): void
     {
         Schema::create('_historial_consulta', function (Blueprint $table) {
             $table->id();
             $table->unsignedBigInteger('paciente_id');
             $table->foreign('paciente_id')->references('id')->on('paciente')->onDelete('cascade');
             $table->unsignedBigInteger('medico_id');
             $table->foreign('medico_id')->references('id')->on('medico')->onDelete('cascade');
             $table->date('fecha');
             $table->string('sintoma_1');
             $table->string('sintoma_2');
             $table->string('sintoma_3');
             $table->string('sintoma_4');
             $table->string('comentarios_medico');
             $table->bigInteger('receta_id');//eliminar
            //  $table->unsignedBigInteger('receta_id');
            //  $table->foreign('receta_id')->references('numero')->on('receta')->onDelete('cascade');
             $table->string('examenes');
             $table->unsignedBigInteger('cita_id');//llenado por bajo
             $table->foreign('cita_id')->references('id')->on('cita')->onDelete('cascade');
             $table->string('peso');
             $table->string('altura');
             $table->string('presion_sanguinea');
             $table->string('glucosa');
             $table->date('fecha_actualizacion');//eliminar
             $table->string('alergia_1');
             $table->string('alergia_2');
             $table->timestamps();
         });
     }
    public function down(): void
    {
        Schema::dropIfExists('historial_consulta');
    }
};
