<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <title>Consulta Recetas</title>
</head>
<body>
    <div class="main-container">
        <div class="row">
            <h1>Consulta de Examenes por Realizar de la Ultima cita</h1>
            <div class="col s12 ">


            </div>

        </div>

    </div>

</body>
</html>