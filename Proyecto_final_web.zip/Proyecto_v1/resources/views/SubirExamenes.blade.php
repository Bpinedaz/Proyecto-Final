<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <title>Subir Examenes</title>
</head>
<body>
<h1> Subir Fotografia del  Examen </h1>

<div class="main-container"> 
    <div >
        <form action="#">
            <div class="file-field input-field">
              <div class="btn">
                <span>File</span>
                <input type="file" multiple>
              </div>
              <div class="file-path-wrapper">
                <input class="file-path validate" type="text" placeholder="Upload one or more files">
              </div>
            </div>
          </form>
          <!--primer div-->
        <div> 
            <form action="#">
                <div class="file-field input-field">
                  <div class="btn">
                    <span>File</span>
                    <input type="file" multiple>
                  </div>
                  <div class="file-path-wrapper">
                    <input class="file-path validate" type="text" placeholder="Upload one or more files">
                  </div>
                </div>
              </form>
                   
            <div>
                   <!--segundo  div-->  
            </div>
             <!--segundo  div-->  
             <div >
                <form action="#">
                    <div class="file-field input-field">
                      <div class="btn">
                        <span>File</span>
                        <input type="file" multiple>
                      </div>
                      <div class="file-path-wrapper">
                        <input class="file-path validate" type="text" placeholder="Upload one or more files">
                      </div>
                    </div>
                  </form>
                  <!--primer div-->
                <div> 
                    <form action="#">
                        <div class="file-field input-field">
                          <div class="btn">
                            <span>File</span>
                            <input type="file" multiple>
                          </div>
                          <div class="file-path-wrapper">
                            <input class="file-path validate" type="text" placeholder="Upload one or more files">
                          </div>
                        </div>
                      </form>
                           
                    <div>
                        <div >
                            <form action="#">
                                <div class="file-field input-field">
                                  <div class="btn">
                                    <span>File</span>
                                    <input type="file" multiple>
                                  </div>
                                  <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text" placeholder="Upload one or more files">
                                  </div>
                                </div>
                              </form>
                              <!--primer div-->
                           
                                                   
                                      
        <a href="MenuPaciente" target="_self">
          <button class="btn waves-effect waves-light" type="submit" name="action">
            Regresar
            <i class="material-icons right">arrow_back</i>
           </button>
        </a>


        

        <button class="btn waves-effect waves-light" type="submit" name="action">Enviar
          <i class="material-icons right">send</i>
        </button>
    </div>
</div>


    
</body>
</html>