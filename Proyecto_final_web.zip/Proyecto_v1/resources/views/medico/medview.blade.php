@foreach ($pacientes as $paciente)
    <p>This is {{$paciente->primer_nombre}}</p>
@endforeach