@extends('layout.layout')

@section('title','Formulario de Citas')

@section('content')
<div class="container">
    <section class="section section-recent">
        <div class="row">
            <div class="col s12 l12 m12">
                <div class="card">
                    <div class="card-content">
                        {{-- <span class="card-title black-text">Ingreso de Consultas</span> --}}
                        <h2>Ingreso de Datos de Consulta</h2>
                        <form action="{{ route('historial.guardar') }}" method="POST">
                            @csrf
                            <label for="nombre">Identidad:</label>
                            <input type="text" id="nombre" name="dni" required>
                            
                            <label for="motivo">Motivo de Consulta:</label>
                            <textarea id="motivo" name="motivo" rows="4" required></textarea>

                            <label for="seguro">Aseguranza( si tiene):</label>
                            <input type="text" id="seguro" name="seguro" required>
                            <!--datos nuevos-->
                            <label for="sintoma1">Primer sintoma:</label>
                            <input type="text" id="sintoma1" name="primersintoma" required>

                            <label for="sintoma2">Segundo sintoma:</label>
                            <input type="text" id="sintoma2" name="segundosintoma" required>

                            <label for="sintoma3">Tercer sintoma:</label>
                            <input type="text" id="sintoma3" name="tercersintoma" required>

                            <label for="comentarios">Comentarios del medico:</label>
                            <input type="text" id="comentarios" name="cometarios" required>

                            <label for="examenes">Examenes:</label>
                            <input type="text" id="examenes" name="examenes" required>

                            <label for="peso">Peso:</label>
                            <input type="number" id="peso" name="peso" required>

                            <label for="altura">Altura:</label>
                            <input type="number" id="altura" name="altura" required>

                            <label for="presion">Presion Sanguinea:</label>
                            <input type="number" id="presion" name="presion" required>

                            <label for="glucosa">Nivel de Glucosa:</label>
                            <input type="number" id="glucosa" name="glucosa" required>

                            <label for="alergia1">Alergia 1:</label>
                            <input type="text" id="alergia1" name="alergia1" required>

                            <label for="alergia2">Alergia 2:</label>
                            <input type="text" id="alergia2" name="alergia2" required>
                            <!--FIN datos nuevos-->                     

                            <button type="submit" class="btn blue lighten-2 white-text">Guardar en Historial</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
@endsection
