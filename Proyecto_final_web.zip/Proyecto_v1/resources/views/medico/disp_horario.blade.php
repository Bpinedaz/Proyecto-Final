<!DOCTYPE html>
<html>
<head>
    <title>Detalles de Consultas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <h1>Detalles de Consultas</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>ID del Paciente</th>
                <th>DNI del Paciente</th>
                <th>ID del Médico</th>
                <th>Fecha de la Cita</th>
                <th>Hora de la Cita</th>
                <th>Exámenes Previos</th>
            </tr>
        </thead>
        <tbody>
            @foreach($citas as $cita)
            <tr>
                <td>{{ $cita->id }}</td>
                <td>{{ $cita->paciente_id }}</td>
                <td>{{ $cita->paciente_dni}}</td>
                <td>{{ $cita->medico_id }}</td>
                <td>{{ $cita->fecha_concertada }}</td>
                <td>{{ $cita->hora_concertada }}</td>
                <td>{{ $cita->examenes_previos }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
